// SWEEPR Deepblock — Manifest V3 Background Service Worker (v1.2 UX & Architecture Audited)
const isDevExtension = false;
const LICENSE_VERIFY_ENDPOINTS = [
  'https://sweeprdeepblock.com/api/license-verify',
  'https://sweepr-crm-production.up.railway.app/v1/license/verify-key?project=deepblock',
  ];

const PRO_ONLY_SETTINGS = new Set([
  'adBlocking',
  'cookieAutoClose',
  'hideSearchSpam',
  'fakeShopAlerts',
  'trackerProtection',
  'silentMode',
  'autoRamTamer'
]);

const scamDetectedTabs = new Set();
const scamReasonsByTab = new Map();
const tabLastActiveAt = new Map();
const AUTO_RAM_IDLE_MS = 10 * 60 * 1000; // 10 minutes idle threshold for automatic background snooze
const OFFLINE_GRACE_MS = 7 * 24 * 60 * 60 * 1000; // 7-day offline verification grace window
const VERIFIED_SESSION_CACHE_TTL_MS = 12 * 60 * 60 * 1000; // 12-hour cache TTL for cold service-worker wakeups

let tabActivityHydrated = false;
let tabActivitySaveScheduled = false;

async function hydrateTabActivityMap() {
  if (tabActivityHydrated) return;
  tabActivityHydrated = true;
  try {
    if (chrome.storage && chrome.storage.session) {
      const s = await chrome.storage.session.get(['tabLastActiveAt']);
      const raw = (s && s.tabLastActiveAt) || {};
      for (const [k, ts] of Object.entries(raw)) {
        const idNum = Number(k);
        if (Number.isFinite(idNum) && typeof ts === 'number' && !tabLastActiveAt.has(idNum)) {
          tabLastActiveAt.set(idNum, ts);
        }
      }
    }
  } catch (e) {}
}

function schedulePersistTabActivityMap() {
  if (tabActivitySaveScheduled || !chrome.storage || !chrome.storage.session) return;
  tabActivitySaveScheduled = true;
  setTimeout(() => {
    tabActivitySaveScheduled = false;
    try {
      const serialized = {};
      for (const [k, v] of tabLastActiveAt.entries()) {
        serialized[k] = v;
      }
      chrome.storage.session.set({ tabLastActiveAt: serialized }).catch(() => {});
    } catch (e) {}
  }, 500);
}

function recordTabActivity(tabId, ts = Date.now()) {
  if (!tabId) return;
  tabLastActiveAt.set(tabId, ts);
  schedulePersistTabActivityMap();
}

function removeTabActivity(tabId) {
  if (!tabId) return;
  tabLastActiveAt.delete(tabId);
  schedulePersistTabActivityMap();
}

function sanitizeTabUrlForBackup(rawUrl) {
  try {
    const u = new URL(String(rawUrl || ''));
    u.hash = '';
    for (const k of [...u.searchParams.keys()]) {
      if (/^(token|access_token|id_token|refresh_token|code|auth|secret|key|session|session_id|password|pass|sig|signature|client_secret)$/i.test(k) || /token|secret|auth|session_id/i.test(k)) {
        u.searchParams.delete(k);
      }
    }
    return u.toString();
  } catch (e) {
    return String(rawUrl || '').split('#')[0];
  }
}

function isNewerSemverExt(latestVer, currentVer) {
  const parse = (v) =>
    String(v || '0.0.0')
      .replace(/^v/i, '')
      .split('-')[0]
      .split('.')
      .map((n) => parseInt(n, 10) || 0);
  const l = parse(latestVer);
  const c = parse(currentVer);
  for (let i = 0; i < Math.max(l.length, c.length); i++) {
    const lv = l[i] || 0;
    const cv = c[i] || 0;
    if (lv > cv) return true;
    if (lv < cv) return false;
  }
  return false;
}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onUpdateAvailable) {
  chrome.runtime.onUpdateAvailable.addListener(() => {
    try {
      chrome.runtime.reload();
    } catch (e) {}
  });
}

async function syncRemoteFilterDelta() {
  try {
    const currentVersion =
      (typeof chrome !== 'undefined' &&
        chrome.runtime &&
        chrome.runtime.getManifest &&
        chrome.runtime.getManifest().version) ||
      '1.1.6';
    const qs = `?current_version=${encodeURIComponent(currentVersion)}`;
    const endpoints = [
      `https://sweeprdeepblock.com/api/filters/delta${qs}`,
      ...(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL
        ? [chrome.runtime.getURL('rules/dynamic_delta.json')]
        : [])
    ];
    let localData = null;
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
      try {
        const localRes = await fetch(chrome.runtime.getURL('rules/dynamic_delta.json'));
        if (localRes.ok) {
          localData = await localRes.json().catch(() => null);
        }
      } catch (err) {}
    }
    let data = null;
    for (const url of endpoints) {
      try {
        const res = await fetch(url, {
          method: 'GET',
          headers: { Accept: 'application/json' },
          signal: AbortSignal.timeout(4000)
        });
        if (res.ok) {
          const parsed = await res.json().catch(() => null);
          if (parsed && parsed.ok) {
            data = parsed;
            break;
          }
        }
      } catch (err) {}
    }
    if (!data && localData && localData.ok) {
      data = localData;
    }
    if (!data || !data.ok) return;
    if (localData && Array.isArray(localData.dynamicDnrRules)) {
      const ruleMap = new Map();
      if (Array.isArray(data.dynamicDnrRules)) {
        for (const r of data.dynamicDnrRules) {
          if (r && typeof r.id === 'number') ruleMap.set(r.id, r);
        }
      }
      for (const r of localData.dynamicDnrRules) {
        if (r && typeof r.id === 'number') ruleMap.set(r.id, r);
      }
      data.dynamicDnrRules = Array.from(ruleMap.values());
    }
    const updates = {};
    if (data.latestExtensionVersion || data.minExtensionVersion) {
      const latestVersion = String(data.latestExtensionVersion || currentVersion).trim();
      const minVersion = String(data.minExtensionVersion || '1.1.6').trim();
      const updateAvailable = Boolean(data.updateAvailable || isNewerSemverExt(latestVersion, currentVersion));
      const forceUpdate = Boolean(
        (data.forceUpdate && updateAvailable) || isNewerSemverExt(minVersion, currentVersion)
      );
      updates.extensionUpdateStatus = {
        currentVersion,
        latestVersion,
        minVersion,
        updateAvailable,
        forceUpdate,
        updateUrl: String(data.storeUpdateUrl || 'https://sweeprdeepblock.com/download'),
        checkedAt: Date.now()
      };
      if (updateAvailable && chrome.runtime && typeof chrome.runtime.requestUpdateCheck === 'function') {
        try {
          chrome.runtime.requestUpdateCheck(() => {});
        } catch (e) {}
      }
    }
    if (data.featureFlags && typeof data.featureFlags === 'object') {
      updates.remoteFeatureFlags = data.featureFlags;
    }
    const sanitizeRemoteSelector = (sel, maxLen = 180) =>
      typeof sel === 'string' &&
      sel.length > 0 &&
      sel.length <= maxLen &&
      /^[a-zA-Z0-9#._:() >[\]="'*~$^|,/-]+$/.test(sel) &&
      !/[{};\\@]/.test(sel) &&
      !/url\(/i.test(sel);
    if (Array.isArray(data.extraCmpSelectors)) {
      updates.extraCmpSelectors = data.extraCmpSelectors.filter((s) => sanitizeRemoteSelector(s, 180)).slice(0, 100);
    }
    if (Array.isArray(data.extraAntiAdblockSelectors)) {
      updates.extraAntiAdblockSelectors = data.extraAntiAdblockSelectors.filter((s) => sanitizeRemoteSelector(s, 180)).slice(0, 100);
    }
    if (Array.isArray(data.extraCosmeticSelectors)) {
      updates.extraCosmeticSelectors = data.extraCosmeticSelectors.filter((s) => sanitizeRemoteSelector(s, 180)).slice(0, 200);
    }
    if (Object.keys(updates).length > 0) {
      await chrome.storage.local.set(updates);
    }
    if (
      Array.isArray(data.dynamicDnrRules) &&
      chrome.declarativeNetRequest &&
      chrome.declarativeNetRequest.updateDynamicRules
    ) {
      if (!verifiedSession.coldChecked) {
        await enforceStoredSubscriptionIntegrity();
      }
      const existing = await chrome.declarativeNetRequest.getDynamicRules();
      const removeRuleIds = existing.filter((r) => r.id >= 80000 && r.id < 81000).map((r) => r.id);
      const validRules =
        verifiedSession.proActive && verifiedSession.licenseKey
          ? data.dynamicDnrRules
              .filter((r) => {
                if (!r || typeof r.id !== 'number' || r.id < 80000 || r.id >= 81000) return false;
                if (!r.action || r.action.type !== 'block') return false;
                if (!r.condition || typeof r.condition !== 'object') return false;
                if (typeof r.condition.urlFilter !== 'string' || r.condition.urlFilter.trim().length < 2) return false;
                if (Array.isArray(r.condition.resourceTypes) && r.condition.resourceTypes.includes('main_frame')) return false;
                return true;
              })
              .slice(0, 500)
          : [];
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds,
        addRules: validRules
      });
    }
  } catch (e) {}
}

async function syncPausedSiteDnrAllowlist(passedPausedSites) {
  try {
    if (!chrome.declarativeNetRequest || !chrome.declarativeNetRequest.updateDynamicRules) return;
    let pausedSites = passedPausedSites;
    if (!Array.isArray(pausedSites)) {
      const stored = await chrome.storage.local.get(['pausedSites']);
      pausedSites = Array.isArray(stored && stored.pausedSites) ? stored.pausedSites : [];
    }
    const cleanDomains = pausedSites
      .map((d) => String(d || '').replace(/^www\./i, '').trim().toLowerCase())
      .filter(Boolean);

    const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = existingRules.filter((r) => r.id >= 90000 && r.id < 91000).map((r) => r.id);

    const addRules = [];
    if (cleanDomains.length > 0) {
      addRules.push({
        id: 90001,
        priority: 100000,
        action: { type: 'allow' },
        condition: {
          initiatorDomains: cleanDomains
        }
      });
    }

    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds,
      addRules
    });
  } catch (e) {}
}

async function syncExtensionProtectionRules(enablePro) {
  try {
    if (!chrome.declarativeNetRequest || !chrome.declarativeNetRequest.updateEnabledRulesets) return;
    if (enablePro) {
      await chrome.declarativeNetRequest.updateEnabledRulesets({
        enableRulesetIds: ['ads_and_trackers'],
        disableRulesetIds: []
      });
      await syncPausedSiteDnrAllowlist();
    } else {
      await chrome.declarativeNetRequest.updateEnabledRulesets({
        enableRulesetIds: [],
        disableRulesetIds: ['ads_and_trackers']
      });
    }
  } catch (e) {}
}

// In-memory anti-tamper session guard inside service worker closure
let verifiedSession = {
  proActive: false,
  ramTamerActive: false,
  licenseKey: '',
  deviceId: '',
  internalWriteInProgress: false
};
let integrityCheckInFlight = null;
const verifyInFlightByKey = new Map();

async function getOrCreateDeviceId() {
  if (verifiedSession.deviceId) return verifiedSession.deviceId;
  const stored = await chrome.storage.local.get(['deviceId']);
  if (stored && typeof stored.deviceId === 'string' && stored.deviceId.startsWith('ext_db_')) {
    verifiedSession.deviceId = stored.deviceId;
    return stored.deviceId;
  }
  const randomPart =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID().replace(/-/g, '').slice(0, 16)
      : Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  const newId = `ext_db_${randomPart}`;
  verifiedSession.deviceId = newId;
  await chrome.storage.local.set({ deviceId: newId });
  return newId;
}

const DEFAULT_STATE = {
  proActive: false,
  ramTamerActive: false,
  licenseKey: '',
  licenseToken: '',
  crmAccountId: '',
  subscriptionStatus: 'unactivated',
  licenseVerifiedAt: 0,
  entitlements: [],
  encryptedDnsEnabled: false,
  pausedSites: [],
  neverSnoozeSites: [],
  trustedShopSites: [],
  customHiddenSelectors: {},
  settings: {
    cookieAutoClose: false,
    hideSearchSpam: false,
    fakeShopAlerts: false,
    trackerProtection: false,
    adBlocking: false,
    silentMode: false,
    autoRamTamer: false
  },
  stats: {
    adsBlocked: 0,
    cookiePromptsDetected: 0,
    cookiePromptsRejected: 0,
    aiSlopDetected: 0,
    fakeStoresDetected: 0,
    clutterStripped: 0,
    antiAdblockBypassed: 0,
    tabsHibernated: 0,
    ramSavedGb: 0
  },
  cloudTabSessions: []
};


// Strictly Anonymous Operational Telemetry (6 Non-Identifying Lifecycle Events — Zero URLs, Domains, Queries, or History)
const ALLOWED_TELEMETRY_EVENTS = new Set([
  'extension_installed',
  'protection_active',
  'first_value_seen',
  'welcome_tab_choice',
  'milestone_reached',
  'heartbeat'
]);

async function sendAnonymousTelemetry(eventName, properties = {}, onceStorageKey = null) {
  try {
    if (!ALLOWED_TELEMETRY_EVENTS.has(eventName)) return { ok: false, error: 'unsupported_event' };
    if (onceStorageKey) {
      const check = await chrome.storage.local.get([onceStorageKey]);
      if (check && check[onceStorageKey]) return { ok: true, skippedDuplicate: true };
      await chrome.storage.local.set({ [onceStorageKey]: Date.now() });
    }
    const deviceId = await getOrCreateDeviceId();
    const manifest = chrome.runtime && chrome.runtime.getManifest ? chrome.runtime.getManifest() : { version: '1.2.7' };
    const safeProps = {};
    if (properties && typeof properties === 'object') {
      for (const [k, v] of Object.entries(properties)) {
        if (!['url', 'domain', 'hostname', 'query', 'path', 'referrer', 'history', 'title'].includes(k.toLowerCase())) {
          safeProps[k] = v;
        }
      }
    }
    await fetch('https://sweeprdeepblock.com/api/telemetry', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event_name: eventName,
        category: 'funnel',
        os: 'browser_extension',
        device_id: deviceId,
        app_version: manifest.version || '1.2.7',
        properties: safeProps
      })
    }).catch(() => {});
    return { ok: true };
  } catch (e) {
    return { ok: false };
  }
}

// Automation A2: Host-Permission & Content-Blocker Activation Rescue Check
async function checkHostPermissionsAndProtection() {
  let granted = true;
  try {
    if (chrome.permissions && typeof chrome.permissions.contains === 'function') {
      granted = await chrome.permissions.contains({ origins: ['<all_urls>'] });
    }
  } catch (e) {
    granted = true;
  }
  try {
    await chrome.storage.local.set({ hostPermissionsGranted: Boolean(granted) });
    if (granted) {
      await sendAnonymousTelemetry(
        'protection_active',
        { host_permissions: 'granted', dnr_enabled: true },
        'telemetrySent_protection_active'
      );
    }
  } catch (e) {}
  return Boolean(granted);
}

async function preserveOfflineGraceSession() {
  const stored = await chrome.storage.local.get(['proActive', 'ramTamerActive', 'licenseKey', 'licenseVerifiedAt', 'entitlements', 'settings']);
  const withinOfflineGrace =
    Boolean(stored.proActive && stored.licenseKey && stored.licenseVerifiedAt) &&
    Date.now() - Number(stored.licenseVerifiedAt) <= OFFLINE_GRACE_MS;
  if (!withinOfflineGrace) {
    return null;
  }
  const adBlockingOn = !stored.settings || stored.settings.adBlocking !== false;
  verifiedSession.proActive = true;
  verifiedSession.ramTamerActive = Boolean(stored.ramTamerActive);
  verifiedSession.licenseKey = String(stored.licenseKey).trim();
  verifiedSession.coldChecked = true;
  await syncExtensionProtectionRules(adBlockingOn);
  return {
    ok: true,
    valid: true,
    networkError: true,
    offlineGrace: true,
    licenseKey: verifiedSession.licenseKey,
    ramTamerActive: verifiedSession.ramTamerActive,
    entitlements: Array.isArray(stored.entitlements) ? stored.entitlements : []
  };
}

// Verify license key against Central SWEEPR CRM & SWEEPR Deepblock Licensing API
async function verifyLicenseWithServer(rawKey) {
  const key = String(rawKey || '').trim();
  if (!key || key.length < 6 || key.length > 512 || key.includes('@')) {
    await revokeProState('invalid_key_format', { preserveLicenseKey: true });
    return { ok: false, valid: false, error: 'Invalid license key format.' };
  }

  if (verifyInFlightByKey.has(key)) {
    return verifyInFlightByKey.get(key);
  }

  const runVerification = (async () => {
    const deviceId = await getOrCreateDeviceId();
    let lastNetworkError = false;
    let sawTransientHttpError = false;
    let lastRejectedResult = null;

    for (const baseUrl of LICENSE_VERIFY_ENDPOINTS) {
      for (let attempt = 0; attempt <= 1; attempt++) {
        try {
          const sep = baseUrl.includes('?') ? '&' : '?';
          const res = await fetch(`${baseUrl}${sep}key=${encodeURIComponent(key)}&device_id=${encodeURIComponent(deviceId)}`, {
            method: 'GET',
            headers: { Accept: 'application/json', 'x-sweepr-project': 'deepblock' },
            signal: AbortSignal.timeout(10000)
          });
          if (res.status === 429 || res.status >= 500) {
            sawTransientHttpError = true;
            if (attempt === 0) {
              const delayMs = 250 + Math.floor(Math.random() * 150);
              await new Promise((r) => setTimeout(r, delayMs));
              continue;
            }
            break;
          }
          const data = await res.json().catch(() => ({}));

          if (res.ok && data && data.valid === true) {
            const subStatus = String(data.status || 'active').toLowerCase();
            if (subStatus === 'active' || subStatus === 'trialing') {
              const addonsList = Array.isArray(data.addons) ? data.addons : [];
              const ramTamerActive = Boolean(
                data.ramTamerAddon === true ||
                  addonsList.includes('ram_tamer') ||
                  addonsList.includes('sweepr_secure_bundle')
              );
              const entitlements = Array.isArray(data.entitlements)
                ? data.entitlements
                : [
                    'pro_cookie_autoreject',
                    'pro_ai_slop_purifier',
                    'pro_clutter_stripper',
                    'bundle_fake_store_detector',
                    'bundle_encrypted_dns_proxy',
                    ...(ramTamerActive ? ['addon_total_tab_and_ram_tamer'] : [])
                  ];
              const canonicalKey = data.licenseKey || data.license_key || key;
              verifiedSession.proActive = true;
              verifiedSession.ramTamerActive = ramTamerActive;
              verifiedSession.licenseKey = canonicalKey;
              verifiedSession.coldChecked = true;
              verifiedSession.internalWriteInProgress = true;
              await chrome.storage.local.set({
                proActive: true,
                ramTamerActive,
                licenseKey: canonicalKey,
                draftLicenseKey: '',
                licenseDrawerOpen: false,
                licenseToken: data.token || data.license_token || '',
                crmAccountId: data.account_id || '',
                subscriptionStatus: subStatus,
                stepUpSaveEligible: Boolean(data.stepUpSaveEligible || data.plan === 'monthly_intro'),
                previousLicenseKey: canonicalKey,
                licenseVerifiedAt: Date.now(),
                entitlements,
                encryptedDnsEnabled: true,
                settings: {
                  cookieAutoClose: true,
                  hideSearchSpam: true,
                  fakeShopAlerts: true,
                  trackerProtection: true,
                  adBlocking: true,
                  silentMode: true,
                  autoRamTamer: true
                }
              });
              verifiedSession.internalWriteInProgress = false;
              chrome.alarms.create('ramTamerCheck', { periodInMinutes: 5 });
              await syncExtensionProtectionRules(true);
              await updateActionBadge();
              return {
                ok: true,
                valid: true,
                status: subStatus,
                licenseKey: canonicalKey,
                ramTamerActive,
                entitlements
              };
            }
          }

          if (res.status === 400 || res.status === 401 || res.status === 403 || res.status === 404 || data?.valid === false) {
            const statusReason = String(data?.status || data?.error || 'inactive').toLowerCase();
            const isExplicitlyInactive =
              res.status === 403 &&
              (statusReason === 'subscription_inactive' ||
                statusReason === 'canceled' ||
                statusReason === 'expired' ||
                statusReason === 'unpaid');
            if (isExplicitlyInactive) {
              await revokeProState(statusReason, { preserveLicenseKey: true });
              return {
                ok: false,
                valid: false,
                status: statusReason,
                error: 'Your Pro subscription is no longer active. Please renew to unlock Pro features.'
              };
            }
            lastRejectedResult = {
              ok: false,
              valid: false,
              status: statusReason,
              error: 'License key not recognized or no active paid subscription found.'
            };
            break;
          }
          break;
        } catch (e) {
          lastNetworkError = true;
          if (attempt === 0) {
            const delayMs = 250 + Math.floor(Math.random() * 150);
            await new Promise((r) => setTimeout(r, delayMs));
          }
        }
      }
    }

    const graced = await preserveOfflineGraceSession();
    if (graced) {
      return graced;
    }

    if (lastRejectedResult && !lastNetworkError && !sawTransientHttpError) {
      return lastRejectedResult;
    }

    return {
      ok: false,
      valid: false,
      networkError: true,
      error: 'Could not reach licensing server to verify subscription. Please check your connection.'
    };
  })();

  verifyInFlightByKey.set(key, runVerification);
  try {
    return await runVerification;
  } finally {
    verifyInFlightByKey.delete(key);
  }
}

async function revokeProState(reason = 'inactive', options = {}) {
  verifiedSession.proActive = false;
  verifiedSession.ramTamerActive = false;
  verifiedSession.licenseKey = '';
  verifiedSession.internalWriteInProgress = true;
  const existing = await chrome.storage.local.get(['churnedAt', 'licenseKey', 'previousLicenseKey']);
  const preservedKey = options.clearLicenseKey ? '' : (existing?.licenseKey || '');
  await chrome.storage.local.set({
    proActive: false,
    ramTamerActive: false,
    licenseKey: preservedKey,
    previousLicenseKey: existing?.previousLicenseKey || existing?.licenseKey || '',
    subscriptionStatus: String(reason),
    churnedAt: existing?.churnedAt || Date.now(),
    licenseVerifiedAt: Date.now(),
    entitlements: [],
    encryptedDnsEnabled: false,
    settings: {
      cookieAutoClose: false,
      hideSearchSpam: false,
      fakeShopAlerts: false,
      trackerProtection: false,
      adBlocking: false,
      silentMode: false,
      autoRamTamer: false
    }
  });
  verifiedSession.internalWriteInProgress = false;
  await syncExtensionProtectionRules(false);
}

// Guard against manual DevTools tampering with chrome.storage.local while honoring legitimate popup/welcome activations
if (chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local' || verifiedSession.internalWriteInProgress) return;
    const newVerifiedAt = Number(changes.licenseVerifiedAt?.newValue || 0);
    const freshKey = String(changes.licenseKey?.newValue || verifiedSession.licenseKey || '').trim();
    if (
      changes.proActive?.newValue === true &&
      freshKey &&
      !freshKey.startsWith('ptk_') &&
      newVerifiedAt > 0 &&
      Date.now() - newVerifiedAt < 15000
    ) {
      verifiedSession.proActive = true;
      verifiedSession.ramTamerActive = Boolean(changes.ramTamerActive?.newValue);
      verifiedSession.licenseKey = freshKey;
      verifiedSession.coldChecked = true;
      syncExtensionProtectionRules(true).catch(() => {});
      return;
    }
    const tamperedPro = changes.proActive && changes.proActive.newValue === true && !verifiedSession.proActive;
    const tamperedRam = changes.ramTamerActive && changes.ramTamerActive.newValue === true && !verifiedSession.ramTamerActive;
    if (tamperedPro || tamperedRam) {
      enforceStoredSubscriptionIntegrity();
    }
  });
}

async function enforceStoredSubscriptionIntegrity(options = {}) {
  const force = Boolean(options && options.force);
  if (integrityCheckInFlight && !force) {
    return integrityCheckInFlight;
  }

  const runIntegrityCheck = (async () => {
    const store = await chrome.storage.local.get(['proActive', 'ramTamerActive', 'licenseKey', 'licenseVerifiedAt', 'settings']);
    const key = String(store.licenseKey || '').trim();
    if (!key || !store.proActive) {
      verifiedSession.coldChecked = true;
      verifiedSession.proActive = false;
      verifiedSession.ramTamerActive = false;
      verifiedSession.licenseKey = '';
      await syncExtensionProtectionRules(false);
      return { proActive: false, ramTamerActive: false };
    }

    const verifiedAt = Number(store.licenseVerifiedAt || 0);
    const ageMs = Date.now() - verifiedAt;
    if (!force && verifiedAt > 0 && ageMs >= 0 && ageMs < VERIFIED_SESSION_CACHE_TTL_MS) {
      verifiedSession.proActive = true;
      verifiedSession.ramTamerActive = Boolean(store.ramTamerActive);
      verifiedSession.licenseKey = key;
      verifiedSession.coldChecked = true;
      const adBlockingOn = !store.settings || store.settings.adBlocking !== false;
      await syncExtensionProtectionRules(adBlockingOn);
      return { proActive: true, ramTamerActive: verifiedSession.ramTamerActive };
    }

    const verified = await verifyLicenseWithServer(key);
    verifiedSession.coldChecked = true;
    if (verified.networkError || verified.offlineGrace) {
      const withinOfflineGrace =
        Boolean(store.licenseVerifiedAt) && Date.now() - Number(store.licenseVerifiedAt) <= OFFLINE_GRACE_MS;
      verifiedSession.proActive = Boolean(store.proActive && key && withinOfflineGrace);
      verifiedSession.ramTamerActive = Boolean(store.proActive && store.ramTamerActive && key && withinOfflineGrace);
      verifiedSession.licenseKey = withinOfflineGrace ? key : '';
      await syncExtensionProtectionRules(verifiedSession.proActive && (!store.settings || store.settings.adBlocking !== false));
      return { proActive: verifiedSession.proActive, ramTamerActive: verifiedSession.ramTamerActive };
    }
    return {
      proActive: Boolean(verified.valid),
      ramTamerActive: Boolean(verified.valid && verified.ramTamerActive)
    };
  })();

  integrityCheckInFlight = runIntegrityCheck;
  try {
    return await runIntegrityCheck;
  } finally {
    if (integrityCheckInFlight === runIntegrityCheck) {
      integrityCheckInFlight = null;
    }
  }
}

async function ensureVerifiedProSession() {
  if (!verifiedSession.coldChecked) {
    await enforceStoredSubscriptionIntegrity();
  }
  return {
    proActive: Boolean(verifiedSession.proActive && verifiedSession.licenseKey),
    ramTamerActive: Boolean(verifiedSession.ramTamerActive && verifiedSession.licenseKey),
    licenseKey: verifiedSession.licenseKey || ''
  };
}

// Immediately ensure DNR rulesets and protection state are active on service worker wakeup
enforceStoredSubscriptionIntegrity()
  .then(() => syncRemoteFilterDelta())
  .catch(() => {});

if (
  typeof chrome !== 'undefined' &&
  chrome.declarativeNetRequest &&
  chrome.declarativeNetRequest.onRuleMatchedDebug
) {
  try {
    chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
      if (info && info.rule && info.rule.rulesetId === 'ads_and_trackers') {
        queueDiagnosticStatIncrement('adsBlocked', 1, () => {});
      }
    });
  } catch (e) {}
}

// Register Desktop Right-Click Context Menus
function registerContextMenus() {
  if (!chrome.contextMenus) return;
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'sweepr-zap-element',
      title: '🧹 Hide distracting element on this page',
      contexts: ['page', 'selection', 'image', 'link']
    });
    chrome.contextMenus.create({
      id: 'sweepr-toggle-site',
      title: 'Pause / Resume SWEEPR Deepblock on this site',
      contexts: ['page', 'action']
    });
    chrome.contextMenus.create({
      id: 'sweepr-snooze-tabs',
      title: '⚡ Snooze Inactive Background Tabs Now',
      contexts: ['page', 'action']
    });
  });
}

chrome.runtime.onInstalled.addListener(async (details) => {
  const existing = await chrome.storage.local.get(Object.keys(DEFAULT_STATE));
  let syncedSessions = [];
  if (chrome.storage && chrome.storage.sync && (!Array.isArray(existing.cloudTabSessions) || existing.cloudTabSessions.length === 0)) {
    try {
      const syncData = await chrome.storage.sync.get(['cloudTabSessions']);
      if (syncData && Array.isArray(syncData.cloudTabSessions)) {
        syncedSessions = syncData.cloudTabSessions;
      }
    } catch (e) {}
  }
  const merged = {
    ...DEFAULT_STATE,
    ...existing,
    cloudTabSessions:
      Array.isArray(existing.cloudTabSessions) && existing.cloudTabSessions.length > 0
        ? existing.cloudTabSessions
        : syncedSessions,
    settings: { ...DEFAULT_STATE.settings, ...(existing.settings || {}) },
    stats: { ...DEFAULT_STATE.stats, ...(existing.stats || {}) }
  };
  await chrome.storage.local.set(merged);
  await hydrateTabActivityMap();
  await enforceStoredSubscriptionIntegrity();
  await updateActionBadge(merged.stats, merged.settings);
  registerContextMenus();
  syncRemoteFilterDelta();
  try {
    if (chrome.runtime && typeof chrome.runtime.setUninstallURL === 'function') {
      chrome.runtime.setUninstallURL('https://sweeprdeepblock.com/support?feedback=uninstall');
    }
  } catch (e) {}

  const hostPermOk = await checkHostPermissionsAndProtection();
  if (details.reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html'), active: false });
    await sendAnonymousTelemetry(
      'extension_installed',
      { host_permissions: hostPermOk ? 'granted' : 'missing' },
      'telemetrySent_extension_installed'
    );
    chrome.alarms.create('activationRescueCheck', { delayInMinutes: 1440 });
  }

  chrome.alarms.create('ramTamerCheck', { periodInMinutes: 5 });
  chrome.alarms.create('licenseVerifyCheck', { periodInMinutes: 720 });
  chrome.alarms.create('filterDeltaSync', { periodInMinutes: 720 });
  chrome.alarms.create('weeklyHeartbeat', { periodInMinutes: 10080 });
});

chrome.runtime.onStartup.addListener(async () => {
  registerContextMenus();
  chrome.alarms.create('ramTamerCheck', { periodInMinutes: 5 });
  chrome.alarms.create('licenseVerifyCheck', { periodInMinutes: 720 });
  chrome.alarms.create('filterDeltaSync', { periodInMinutes: 720 });
  chrome.alarms.create('weeklyHeartbeat', { periodInMinutes: 10080 });
  await checkHostPermissionsAndProtection();
  await hydrateTabActivityMap();
  await enforceStoredSubscriptionIntegrity();
  syncRemoteFilterDelta();
});

// Ensure dynamic DNR rules and remote filter deltas are synced whenever the service worker wakes
syncRemoteFilterDelta();

// Dynamic Per-Tab Toolbar Action Badge:
// - Shows "OFF" (slate #64748b) when the active tab's domain is in pausedSites
// - Shows "!" (amber #d97706) when the active tab triggered a fake-shop alert
// - Otherwise stays completely empty in 100% Silent Mode, or shows counter in Visual Mode
async function updateActionBadge(passedStats, passedSettings) {
  try {
    const [stored, tabs] = await Promise.all([
      chrome.storage.local.get(['stats', 'settings', 'pausedSites', 'proActive', 'hostPermissionsGranted', 'activationRescueBadge']),
      chrome.tabs.query({ active: true, currentWindow: true })
    ]);
    const stats = passedStats || (stored && stored.stats) || DEFAULT_STATE.stats;
    const settings = passedSettings || (stored && stored.settings) || DEFAULT_STATE.settings;
    const pausedSites = Array.isArray(stored && stored.pausedSites) ? stored.pausedSites : [];
    const activeTab = tabs && tabs[0];

    if (stored && (stored.hostPermissionsGranted === false || stored.activationRescueBadge === true)) {
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
      return;
    }

    if (activeTab && activeTab.url && /^https?:\/\//i.test(activeTab.url)) {
      try {
        const host = new URL(activeTab.url).hostname.replace(/^www\./i, '').toLowerCase();
        if (host && pausedSites.includes(host)) {
          chrome.action.setBadgeText({ text: 'OFF' });
          chrome.action.setBadgeBackgroundColor({ color: '#64748b' });
          return;
        }
        if (activeTab.id && scamDetectedTabs.has(activeTab.id)) {
          chrome.action.setBadgeText({ text: '!' });
          chrome.action.setBadgeBackgroundColor({ color: '#d97706' });
          return;
        }
      } catch (e) {}
    }

    const silentMode = settings.silentMode !== false;
    if (silentMode) {
      chrome.action.setBadgeText({ text: '' });
      return;
    }
    const totalAlerts =
      (stats.cookiePromptsDetected || 0) +
      (stats.aiSlopDetected || 0) +
      (stats.fakeStoresDetected || 0);
    chrome.action.setBadgeText({ text: totalAlerts > 0 ? String(totalAlerts) : '' });
    chrome.action.setBadgeBackgroundColor({ color: '#059669' });
  } catch (e) {}
}

const POPUNDER_TAB_URL_REGEX =
  /(\/zv3\/(b|url|cam)|\/link\/out\/|\/getape\/|\/prepop\.php|\/getadb\/|\/venor\.php|\/v1\/link\.php|\/splash\.php\?idzone=|\/api\/click\/|\/click\.go|\/loadeactrl\.go|tsyndicate\.com|contentsserved\.com|exoclick\.com|exosrv\.com|realsrv\.com|magsrv\.com|pemsrv\.com|orbsrv\.com|trafficjunky\.(net|com)|juicyads\.com|jads\.co|clickadu\.com|clickaine\.com|hilltopads\.net|adspyglass\.com|plugrush\.com|adxpansion\.com|crakrevenue\.com|twinrdsyn\.com|twinrdengine\.com|adtng\.com|etahub\.com|bngpt\.com|xlivrdr\.com|popads\.net|popcash\.net|propellerads\.com|u5s5\.com|fh-wgt\.com|cupbearergrowllurch\.com|hollowgoal\.com|fhgte\.com|directsle\.com|qoqh\.com|lxax\.com|koxk\.com|applzr\.com|goadserver\.com|yequka\.my|rvmessage\.online|rvrpushserv\.com|advnet\.xyz|zog\.link|iloptrex\.com|vidvas3\.com|pagerrentablespotlight\.com|holaraphraus\.com|terschomonic\.com|enomotia\.com|janitorprecisiontrio\.com|earthspetti\.com|displayvertising\.com|jusgrmawfbaqu\.com|bspyoibtwrrc\.com|cemhlobja\.com|d3mzokty951c5w\.cloudfront\.net|ey43\.com|adsco\.re)/i;

const STRICT_POPUNDER_OPENER_HOSTS = new Set(['vidara.to', 'vidara.so', 'as9u7bgh9.com']);

const newlySpawnedChildTabs = new Map();
let lastActiveHttpTabId = null;

function normalizeHost(rawUrl) {
  try {
    return new URL(String(rawUrl || '')).hostname.replace(/^www\./i, '').toLowerCase();
  } catch (e) {
    return '';
  }
}

async function checkAndClosePopunderTab(tabId, candidateUrl, openerTabId) {
  if (!tabId || !candidateUrl || /^(chrome(-extension)?|edge|about|moz-extension):\/\//i.test(candidateUrl)) return false;
  try {
    const store = await chrome.storage.local.get(['settings', 'pausedSites']);
    const settings = store.settings || DEFAULT_STATE.settings;
    if (settings.adBlocking === false) return false;
    const pausedSites = Array.isArray(store.pausedSites) ? store.pausedSites : [];

    let openerHost = '';
    const effectiveOpenerId = openerTabId || (lastActiveHttpTabId !== tabId ? lastActiveHttpTabId : null);
    if (effectiveOpenerId) {
      try {
        const openerTab = await chrome.tabs.get(effectiveOpenerId);
        openerHost = normalizeHost(openerTab && openerTab.url);
      } catch (e) {}
    }
    if (openerHost && pausedSites.includes(openerHost)) return false;

    const childHost = normalizeHost(candidateUrl);
    const isAdUrl = POPUNDER_TAB_URL_REGEX.test(candidateUrl);
    const isCrossOriginFromStrictTube =
      Boolean(openerHost && STRICT_POPUNDER_OPENER_HOSTS.has(openerHost)) &&
      Boolean(childHost && childHost !== openerHost && !childHost.endsWith('.' + openerHost));

    if (isAdUrl || isCrossOriginFromStrictTube) {
      newlySpawnedChildTabs.delete(tabId);
      await chrome.tabs.remove(tabId);
      if (effectiveOpenerId) {
        try {
          await chrome.tabs.update(effectiveOpenerId, { active: true });
        } catch (e) {}
      }
      queueDiagnosticStatIncrement('adsBlocked', 1);
      return true;
    }
  } catch (e) {}
  return false;
}

// Refresh toolbar badge whenever user switches tabs or navigates, and kill popunder ad tabs
if (chrome.tabs) {
  if (chrome.tabs.onCreated) {
    chrome.tabs.onCreated.addListener((tab) => {
      if (!tab || !tab.id) return;
      const initialUrl = tab.pendingUrl || tab.url || '';
      if (/^(chrome|edge|about):\/\/newtab/i.test(initialUrl) || initialUrl === 'about:newtab') return;
      const effectiveOpenerId = tab.openerTabId || (lastActiveHttpTabId !== tab.id ? lastActiveHttpTabId : undefined);
      if (!effectiveOpenerId && !POPUNDER_TAB_URL_REGEX.test(initialUrl)) return;
      newlySpawnedChildTabs.set(tab.id, {
        openerTabId: effectiveOpenerId,
        createdAt: Date.now()
      });
      if (initialUrl && initialUrl !== 'about:blank') {
        checkAndClosePopunderTab(tab.id, initialUrl, effectiveOpenerId);
      }
    });
  }
  if (chrome.tabs.onActivated) {
    chrome.tabs.onActivated.addListener((activeInfo) => {
      if (activeInfo && activeInfo.tabId) {
        recordTabActivity(activeInfo.tabId, Date.now());
        if (!newlySpawnedChildTabs.has(activeInfo.tabId)) {
          chrome.tabs.get(activeInfo.tabId, (t) => {
            if (!chrome.runtime.lastError && t && /^https?:\/\//i.test(t.url || '')) {
              lastActiveHttpTabId = t.id;
            }
          });
        }
      }
      updateActionBadge();
    });
  }
  if (chrome.tabs.onUpdated) {
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      const childMeta = newlySpawnedChildTabs.get(tabId);
      if (childMeta) {
        if (Date.now() - childMeta.createdAt > 4000) {
          newlySpawnedChildTabs.delete(tabId);
        } else {
          const nextUrl = changeInfo.url || (tab && (tab.pendingUrl || tab.url)) || '';
          if (nextUrl && nextUrl !== 'about:blank') {
            checkAndClosePopunderTab(tabId, nextUrl, childMeta.openerTabId);
          }
          if (changeInfo.status === 'complete' && nextUrl && nextUrl !== 'about:blank') {
            newlySpawnedChildTabs.delete(tabId);
          }
        }
      } else if (tab && tab.active && /^https?:\/\//i.test(tab.url || '')) {
        lastActiveHttpTabId = tabId;
      }
      if (tab && tab.active) {
        recordTabActivity(tabId, Date.now());
      }
      if (changeInfo.status === 'loading') {
        scamDetectedTabs.delete(tabId);
        scamReasonsByTab.delete(tabId);
      }
      if (changeInfo.status === 'complete' || changeInfo.url) {
        updateActionBadge();
      }
    });
  }
  if (chrome.tabs.onRemoved) {
    chrome.tabs.onRemoved.addListener((tabId) => {
      newlySpawnedChildTabs.delete(tabId);
      removeTabActivity(tabId);
      scamDetectedTabs.delete(tabId);
      scamReasonsByTab.delete(tabId);
    });
  }
}

// Helper to toggle site pause by hostname
async function toggleSitePauseByHostname(rawHostname) {
  const host = String(rawHostname || '').replace(/^www\./i, '').trim().toLowerCase();
  if (!host) return { ok: false };
  const [auth, res] = await Promise.all([
    ensureVerifiedProSession(),
    chrome.storage.local.get(['pausedSites'])
  ]);
  if (!auth.proActive || !auth.licenseKey) {
    return {
      ok: false,
      requiresPro: true,
      error: 'Active paid Pro subscription required to enable website protection.'
    };
  }
  const current = Array.isArray(res.pausedSites) ? res.pausedSites : [];
  const isPaused = current.includes(host);
  const updated = isPaused ? current.filter((h) => h !== host) : [...current, host];
  await chrome.storage.local.set({ pausedSites: updated });
  await syncPausedSiteDnrAllowlist(updated);
  await updateActionBadge();
  return { ok: true, pausedSites: updated, paused: !isPaused, hostname: host };
}

// Right-Click Context Menu Handler
if (chrome.contextMenus && chrome.contextMenus.onClicked) {
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === 'sweepr-zap-element' && tab && tab.id) {
      chrome.tabs.sendMessage(tab.id, { type: 'START_ELEMENT_ZAPPER' });
    } else if (info.menuItemId === 'sweepr-toggle-site' && tab && tab.url && /^https?:\/\//i.test(tab.url)) {
      try {
        const hostname = new URL(tab.url).hostname;
        const res = await toggleSitePauseByHostname(hostname);
        if (res.ok && tab.id) {
          chrome.tabs.reload(tab.id);
        }
      } catch (e) {}
    } else if (info.menuItemId === 'sweepr-snooze-tabs') {
      await hibernateInactiveTabs();
    }
  });
}

// Keyboard-First Shortcuts (Alt+Shift+S / Alt+Shift+Z)
if (chrome.commands && chrome.commands.onCommand) {
  chrome.commands.onCommand.addListener(async (command) => {
    if (command === 'toggle-site-protection') {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const activeTab = tabs && tabs[0];
      if (activeTab && activeTab.url && /^https?:\/\//i.test(activeTab.url)) {
        try {
          const hostname = new URL(activeTab.url).hostname;
          const res = await toggleSitePauseByHostname(hostname);
          if (res.ok && activeTab.id) {
            chrome.tabs.reload(activeTab.id);
          }
        } catch (e) {}
      }
    } else if (command === 'snooze-inactive-tabs') {
      await hibernateInactiveTabs();
    }
  });
}

// Compute live RAM Speedometer metrics (Zero-permission tab heuristic)
async function getRamSpeedometerMetrics() {
  const tabs = await chrome.tabs.query({});
  const activeTabs = tabs.filter((t) => !t.discarded);
  const discardedCount = tabs.filter((t) => t.discarded).length;

  const estimatedGb = Math.max(0.8, +(0.65 + activeTabs.length * 0.145).toFixed(1));
  const slowdownPct = Math.min(78, Math.max(8, Math.round(estimatedGb * 6.2)));

  return {
    totalTabs: tabs.length,
    activeTabsCount: activeTabs.length,
    discardedCount,
    estimatedGb,
    slowdownPct
  };
}

// Hibernate inactive background tabs & snapshot session to Cloud Vault
async function hibernateInactiveTabs(options = {}) {
  const isAutoBackground = Boolean(options && options.isAutoBackground);
  const verified = await ensureVerifiedProSession();
  if (!verified.proActive || !verified.licenseKey) {
    return { ok: false, requiresPro: true, error: 'Active paid Pro subscription required.' };
  }
  await hydrateTabActivityMap();
  const data = await chrome.storage.local.get(['stats', 'cloudTabSessions', 'neverSnoozeSites', 'settings']);

  const stats = data.stats || DEFAULT_STATE.stats;
  const neverSnoozeSites = Array.isArray(data.neverSnoozeSites) ? data.neverSnoozeSites : [];
  const tabs = await chrome.tabs.query({});
  const now = Date.now();

  let newlyDiscarded = 0;
  for (const tab of tabs) {
    if (tab.active && tab.id) {
      recordTabActivity(tab.id, now);
      continue;
    }
    if (!tab.active && !tab.pinned && !tab.audible && !tab.discarded && tab.id) {
      let tabHost = '';
      try {
        if (tab.url && /^https?:\/\//i.test(tab.url)) {
          tabHost = new URL(tab.url).hostname.replace(/^www\./i, '').toLowerCase();
        }
      } catch (e) {}
      if (tabHost && neverSnoozeSites.includes(tabHost)) {
        continue;
      }
      if (isAutoBackground) {
        const lastActive = tabLastActiveAt.get(tab.id);
        if (!lastActive) {
          recordTabActivity(tab.id, now);
          continue;
        }
        if (now - lastActive < AUTO_RAM_IDLE_MS) {
          continue;
        }
      }
      try {
        await chrome.tabs.discard(tab.id);
        newlyDiscarded++;
      } catch (e) {}
    }
  }

  let sessions = Array.isArray(data.cloudTabSessions) ? data.cloudTabSessions : [];
  if (!isAutoBackground || newlyDiscarded > 0) {
    const sanitizedTabs = tabs
      .filter((t) => t.url && /^https?:\/\//i.test(t.url))
      .slice(0, 30)
      .map((t) => ({
        title: String(t.title || 'Saved Page').slice(0, 120),
        url: sanitizeTabUrlForBackup(t.url || '')
      }));
    const newSignature = sanitizedTabs.map((t) => t.url).join('|');
    const prevSignature =
      sessions[0] && Array.isArray(sessions[0].tabs)
        ? sessions[0].tabs.map((t) => t.url).join('|')
        : '';

    const snapshot = {
      id: prevSignature && prevSignature === newSignature ? sessions[0].id : 'session-' + now,
      savedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      tabCount: tabs.length,
      tabs: sanitizedTabs
    };
    if (prevSignature && prevSignature === newSignature) {
      sessions = [snapshot, ...sessions.slice(1)].slice(0, 5);
    } else {
      sessions = [snapshot, ...sessions].slice(0, 5);
    }
  }

  const savedGbAdd = +(newlyDiscarded * 0.14).toFixed(1);
  stats.tabsHibernated = (stats.tabsHibernated || 0) + newlyDiscarded;
  stats.ramSavedGb = +((stats.ramSavedGb || 0) + savedGbAdd).toFixed(1);

  const updatedSettings = { ...DEFAULT_STATE.settings, ...(data.settings || {}) };
  if (!isAutoBackground) {
    updatedSettings.autoRamTamer = true;
    chrome.alarms.create('ramTamerCheck', { periodInMinutes: 5 });
  }

  await chrome.storage.local.set({ stats, cloudTabSessions: sessions, settings: updatedSettings });
  if (chrome.storage && chrome.storage.sync && sessions.length > 0) {
    try {
      const compactSyncSessions = sessions.slice(0, 2).map((s) => ({
        id: s.id,
        savedAt: s.savedAt,
        tabCount: s.tabCount,
        tabs: (s.tabs || []).slice(0, 15).map((t) => ({
          title: String(t.title || '').slice(0, 60),
          url: String(t.url || '').slice(0, 200)
        }))
      }));
      chrome.storage.sync.set({ cloudTabSessions: compactSyncSessions }).catch(() => {});
    } catch (e) {}
  }
  return { ok: true, newlyDiscarded, savedGbAdd, stats, sessions, settings: updatedSettings };
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name && alarm.name.startsWith('resumeSite:')) {
    const hostToResume = alarm.name.slice('resumeSite:'.length).trim().toLowerCase();
    if (hostToResume) {
      const res = await chrome.storage.local.get(['pausedSites']);
      const current = Array.isArray(res.pausedSites) ? res.pausedSites : [];
      const updated = current.filter((h) => h !== hostToResume);
      await chrome.storage.local.set({ pausedSites: updated });
      await syncPausedSiteDnrAllowlist(updated);
      await updateActionBadge();
    }
    return;
  }
  if (alarm.name === 'licenseVerifyCheck') {
    await enforceStoredSubscriptionIntegrity({ force: true });
    return;
  }
  if (alarm.name === 'filterDeltaSync') {
    await syncRemoteFilterDelta();
    return;
  }
  if (alarm.name === 'weeklyHeartbeat') {
    const store = await chrome.storage.local.get(['proActive', 'hostPermissionsGranted']);
    await sendAnonymousTelemetry('heartbeat', {
      tier: store && store.proActive ? 'pro' : 'free',
      host_permissions: store && store.hostPermissionsGranted === false ? 'missing' : 'granted'
    });
    return;
  }
  if (alarm.name === 'activationRescueCheck') {
    const hostOk = await checkHostPermissionsAndProtection();
    const store = await chrome.storage.local.get(['stats']);
    const st = (store && store.stats) || DEFAULT_STATE.stats;
    const totalBlocks = (st.adsBlocked || 0) + (st.cookiePromptsDetected || 0) + (st.aiSlopDetected || 0) + (st.fakeStoresDetected || 0);
    if (!hostOk || totalBlocks === 0) {
      await chrome.storage.local.set({ activationRescueBadge: true });
      await updateActionBadge();
    }
    return;
  }
  if (alarm.name === 'ramTamerCheck') {
    const { proActive, licenseKey, settings, remoteFeatureFlags } = await chrome.storage.local.get([
      'proActive',
      'licenseKey',
      'settings',
      'remoteFeatureFlags'
    ]);
    const autoEnabled =
      (!settings || settings.autoRamTamer !== false) &&
      (!remoteFeatureFlags || remoteFeatureFlags.autoRamTamer !== false);
    if (proActive && licenseKey && autoEnabled) {
      await hibernateInactiveTabs({ isAutoBackground: true });
    }
  }
});

const pendingStatIncrements = new Map();
let statFlushInFlight = false;
let statFlushCallbacks = [];

function queueDiagnosticStatIncrement(metric, amount, callback) {
  if (metric && Object.prototype.hasOwnProperty.call(DEFAULT_STATE.stats, metric)) {
    const safeAmount = Math.min(20, Math.max(1, Number(amount) || 1));
    pendingStatIncrements.set(metric, (pendingStatIncrements.get(metric) || 0) + safeAmount);
  }
  if (typeof callback === 'function') {
    statFlushCallbacks.push(callback);
  }
  if (statFlushInFlight) return;
  statFlushInFlight = true;
  setTimeout(async () => {
    const batch = new Map(pendingStatIncrements);
    const callbacks = statFlushCallbacks.splice(0, statFlushCallbacks.length);
    pendingStatIncrements.clear();
    try {
      const res = await chrome.storage.local.get(['stats', 'settings']);
      const stats = { ...DEFAULT_STATE.stats, ...(res.stats || {}) };
      for (const [k, delta] of batch.entries()) {
        if (typeof stats[k] === 'number') {
          stats[k] += delta;
        }
      }
      await chrome.storage.local.set({ stats, activationRescueBadge: false });
      await updateActionBadge(stats, res.settings);
      const totalBlocks =
        (stats.adsBlocked || 0) +
        (stats.cookiePromptsDetected || 0) +
        (stats.aiSlopDetected || 0) +
        (stats.fakeStoresDetected || 0);
      if (totalBlocks >= 1) {
        sendAnonymousTelemetry('first_value_seen', { total_blocks: totalBlocks }, 'telemetrySent_first_value_seen').catch(() => {});
      }
      for (const m of [100, 500, 1000, 10000]) {
        if (totalBlocks >= m) {
          sendAnonymousTelemetry('milestone_reached', { milestone: m }, `telemetrySent_milestone_${m}`).catch(() => {});
        }
      }
      for (const cb of callbacks) {
        try {
          cb({ ok: true, stats });
        } catch (e) {}
      }
    } catch (e) {
      for (const cb of callbacks) {
        try {
          cb({ ok: false });
        } catch (err) {}
      }
    } finally {
      statFlushInFlight = false;
      if (pendingStatIncrements.size > 0) {
        queueDiagnosticStatIncrement(null, 0);
      }
    }
  }, 120);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return false;
  if (sender && sender.id && sender.id !== chrome.runtime.id) return false;

  // Allow Zero-Copy Website Auto-Activation Bridge from sweeprdeepblock.com
  if (msg.type === 'AUTO_SYNC_WEBSITE_LICENSE') {
    const senderUrl = String((sender && sender.url) || '');
    const tabUrl = String((sender && sender.tab && sender.tab.url) || '');
    const isFrameZero = !sender || sender.frameId === 0;
    const isOfficialUrl = (u) =>
      /^https:\/\/([a-z0-9-]+\.)?sweeprdeepblock\.com(\/|$)/i.test(u) ||
      (isDevExtension && /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?(\/|$)/i.test(u));

    if (!isFrameZero || !isOfficialUrl(senderUrl) || (tabUrl && !isOfficialUrl(tabUrl))) {
      sendResponse({ ok: false, error: 'untrusted_origin' });
      return true;
    }

    const key = String(msg.licenseKey || '').trim();
    if (!key || key.length < 6 || key.length > 128 || key.includes('@')) {
      sendResponse({ ok: false });
      return true;
    }
    verifyLicenseWithServer(key).then((result) => {
      sendResponse(result);
    });
    return true;
  }

  if (msg.type === 'INCREMENT_DIAGNOSTIC') {
    if (msg.metric === 'fakeStoresDetected' && sender && sender.tab && sender.tab.id) {
      scamDetectedTabs.add(sender.tab.id);
      if (Array.isArray(msg.reasons) && msg.reasons.length > 0) {
        scamReasonsByTab.set(sender.tab.id, msg.reasons);
      }
    }
    queueDiagnosticStatIncrement(msg.metric, msg.amount, sendResponse);
    return true;
  }

  // Privileged extension UI actions (popup & options pages)
  const extBaseUrl = chrome.runtime.getURL('');
  const senderUrl = String((sender && sender.url) || '');
  const isPrivilegedExtensionPage = Boolean(extBaseUrl && senderUrl.startsWith(extBaseUrl));
  if (!isPrivilegedExtensionPage) {
    return false;
  }

  if (msg.type === 'GET_DASHBOARD_STATE') {
    Promise.all([
      chrome.storage.local.get([
        ...Object.keys(DEFAULT_STATE),
        'extensionUpdateStatus',
        'hostPermissionsGranted',
        'stepUpSaveEligible',
        'previousLicenseKey',
        'churnedAt',
        'simulatedWinbackTier',
        'abVariantOverride',
        'deviceId'
      ]),
      getRamSpeedometerMetrics(),
      chrome.tabs.query({ active: true, currentWindow: true })
    ]).then(async ([store, ramMetrics, activeTabs]) => {
      const auth = await ensureVerifiedProSession();
      const deviceId = store.deviceId || (await getOrCreateDeviceId());
      const activeTab = activeTabs && activeTabs[0];
      const activeTabId = activeTab ? activeTab.id : null;
      const currentTabScamDetected = Boolean(activeTabId && scamDetectedTabs.has(activeTabId));
      const currentTabScamReasons = (activeTabId && scamReasonsByTab.get(activeTabId)) || [];
      const mergedStats = { ...DEFAULT_STATE.stats, ...(store.stats || {}) };
      const totalThreats =
        (Number(mergedStats.adsBlocked) || 0) +
        (Number(mergedStats.cookiePromptsDetected) || 0) +
        (Number(mergedStats.aiSlopDetected) || 0) +
        (Number(mergedStats.fakeStoresDetected) || 0);
      const milestoneState = {
        totalThreats,
        secondsSaved: Math.max(1, Math.round(totalThreats * 0.42)),
        reached100: totalThreats >= 100,
        reached500: totalThreats >= 500,
        reached1000: totalThreats >= 1000
      };
      const stepUpSaveEligible = Boolean(store.stepUpSaveEligible);
      const winbackEligible = Boolean(
        !auth.proActive &&
          (store.simulatedWinbackTier ||
            (store.previousLicenseKey &&
              ['canceled', 'expired', 'inactive', 'unverified'].includes(String(store.subscriptionStatus || ''))))
      );
      const daysSinceChurn = Math.max(0, Math.floor((Date.now() - Number(store.churnedAt || Date.now())) / 86400000));
      const winbackTier =
        store.simulatedWinbackTier ||
        (daysSinceChurn >= 90 ? 'tier_d90' : daysSinceChurn >= 60 ? 'tier_d60' : 'tier_d30');
      const charSum = String(deviceId)
        .split('')
        .reduce((acc, ch) => acc + ch.charCodeAt(0), 0);
      const abVariant =
        store.abVariantOverride ||
        store.abVariantServer ||
        (charSum % 2 === 0 ? 'variant_a_breadth' : 'variant_b_risk_free_14d');
      if (!store.abVariantFetchedAt || Date.now() - Number(store.abVariantFetchedAt) > 6 * 3600 * 1000) {
        fetch('https://sweeprdeepblock.com/api/ab/paywall?vid=' + encodeURIComponent(deviceId))
          .then((r) => (r.ok ? r.json() : null))
          .then((data) => {
            if (data && data.variant) {
              chrome.storage.local.set({ abVariantServer: data.variant, abVariantFetchedAt: Date.now() });
            }
          })
          .catch(() => {});
      }

      sendResponse({
        ...DEFAULT_STATE,
        ...store,
        proActive: Boolean(auth.proActive),
        ramTamerActive: Boolean(auth.ramTamerActive),
        licenseKey: auth.licenseKey || '',
        settings: { ...DEFAULT_STATE.settings, ...(store.settings || {}) },
        stats: mergedStats,
        milestoneState,
        stepUpSaveEligible,
        winbackEligible,
        winbackTier,
        daysSinceChurn,
        abVariant,
        ramMetrics,
        currentTabScamDetected,
        currentTabScamReasons,
        hostPermissionsGranted: store.hostPermissionsGranted !== false,
        extensionUpdateStatus: store.extensionUpdateStatus || null
      });
    });
    return true;
  }

  if (msg.type === 'SIMULATE_WINBACK_TIER') {
    const tier = ['tier_d30', 'tier_d60', 'tier_d90'].includes(msg.tier) ? msg.tier : null;
    chrome.storage.local.set({ simulatedWinbackTier: tier }, () => {
      sendResponse({ ok: true, simulatedWinbackTier: tier });
    });
    return true;
  }

  if (msg.type === 'HIBERNATE_TABS_NOW') {
    ensureVerifiedProSession().then(async (auth) => {
      if (!auth.proActive || !auth.licenseKey) {
        sendResponse({
          ok: false,
          requiresPro: true,
          error: 'Active paid Pro subscription required for Browser Speed & Tab Hibernation.'
        });
        return;
      }
      const result = await hibernateInactiveTabs();
      const ramMetrics = await getRamSpeedometerMetrics();
      sendResponse({ ...result, ramMetrics });
    });
    return true;
  }

  if (msg.type === 'TOGGLE_SITE_PAUSE') {
    toggleSitePauseByHostname(msg.hostname).then(async (res) => {
      if (res && res.ok && msg.reloadTabId) {
        try {
          await chrome.tabs.reload(msg.reloadTabId);
        } catch (e) {}
      }
      sendResponse(res);
    });
    return true;
  }

  if (msg.type === 'PAUSE_SITE_5_MIN') {
    const host = String(msg.hostname || '').replace(/^www\./i, '').trim().toLowerCase();
    Promise.all([ensureVerifiedProSession(), chrome.storage.local.get(['pausedSites'])]).then(async ([auth, res]) => {
      if (!auth.proActive || !auth.licenseKey) {
        sendResponse({
          ok: false,
          requiresPro: true,
          error: 'Active paid Pro subscription required.'
        });
        return;
      }
      if (!host) {
        sendResponse({ ok: false });
        return;
      }
      const current = Array.isArray(res.pausedSites) ? res.pausedSites : [];
      const updated = current.includes(host) ? current : [...current, host];
      await chrome.storage.local.set({ pausedSites: updated });
      await syncPausedSiteDnrAllowlist(updated);
      chrome.alarms.create(`resumeSite:${host}`, { delayInMinutes: 5 });
      await updateActionBadge();
      if (msg.reloadTabId) {
        try {
          await chrome.tabs.reload(msg.reloadTabId);
        } catch (e) {}
      }
      sendResponse({ ok: true, pausedSites: updated, paused: true, hostname: host, resumesInMinutes: 5 });
    });
    return true;
  }

  if (msg.type === 'TOGGLE_NEVER_SNOOZE_SITE') {
    const host = String(msg.hostname || '').replace(/^www\./i, '').trim().toLowerCase();
    chrome.storage.local.get(['neverSnoozeSites'], async (res) => {
      if (!host) {
        sendResponse({ ok: false });
        return;
      }
      const current = Array.isArray(res.neverSnoozeSites) ? res.neverSnoozeSites : [];
      const keptAwake = !current.includes(host);
      const updated = keptAwake ? [...current, host] : current.filter((h) => h !== host);
      await chrome.storage.local.set({ neverSnoozeSites: updated });
      sendResponse({ ok: true, neverSnoozeSites: updated, keptAwake, hostname: host });
    });
    return true;
  }

  if (msg.type === 'TOGGLE_SETTING') {
    const key = String(msg.settingKey || '').trim();
    if (!Object.prototype.hasOwnProperty.call(DEFAULT_STATE.settings, key)) {
      sendResponse({ ok: false });
      return true;
    }
    Promise.all([ensureVerifiedProSession(), chrome.storage.local.get(['settings', 'stats'])]).then(async ([auth, res]) => {
      const hasPaidPro = Boolean(auth.proActive && auth.licenseKey);
      if (PRO_ONLY_SETTINGS.has(key) && !hasPaidPro) {
        sendResponse({
          ok: false,
          requiresPro: true,
          error: 'Active paid Pro subscription required to toggle this feature.'
        });
        return;
      }
      const current = { ...DEFAULT_STATE.settings, ...(res.settings || {}) };
      current[key] = !current[key];
      await chrome.storage.local.set({ settings: current });
      if (key === 'adBlocking') {
        await syncExtensionProtectionRules(Boolean(current.adBlocking));
      }
      if (key === 'silentMode') {
        await updateActionBadge(res.stats || DEFAULT_STATE.stats, current);
      }
      sendResponse({ ok: true, settings: current });
    });
    return true;
  }

  if (msg.type === 'RESTORE_SAVED_SESSION') {
    const sessionId = String(msg.sessionId || '');
    Promise.all([ensureVerifiedProSession(), chrome.storage.local.get(['cloudTabSessions'])]).then(async ([auth, res]) => {
      if (!auth.proActive || !auth.licenseKey) {
        sendResponse({ ok: false, requiresPro: true, error: 'Active paid Pro subscription required.' });
        return;
      }
      const sessions = Array.isArray(res.cloudTabSessions) ? res.cloudTabSessions : [];
      const found = sessions.find((s) => s.id === sessionId) || sessions[0];
      let restoredCount = 0;
      if (found && Array.isArray(found.tabs)) {
        for (const t of found.tabs.slice(0, 15)) {
          if (t.url && /^https?:\/\//i.test(t.url)) {
            try {
              await chrome.tabs.create({ url: t.url, active: false });
              restoredCount++;
            } catch (e) {}
          }
        }
      }
      sendResponse({ ok: true, restoredCount });
    });
    return true;
  }

  if (msg.type === 'SEND_TELEMETRY_EVENT') {
    const evName = String(msg.eventName || '').trim();
    const props = msg.properties && typeof msg.properties === 'object' ? msg.properties : {};
    const onceKey = msg.onceKey ? String(msg.onceKey) : null;
    sendAnonymousTelemetry(evName, props, onceKey).then((res) => sendResponse(res));
    return true;
  }

  if (msg.type === 'CHECK_HOST_PERMISSIONS') {
    checkHostPermissionsAndProtection().then(async (granted) => {
      if (granted) {
        await chrome.storage.local.set({ activationRescueBadge: false });
        await updateActionBadge();
      }
      sendResponse({ ok: true, hostPermissionsGranted: granted });
    });
    return true;
  }

  if (msg.type === 'ACTIVATE_LICENSE' || msg.type === 'VERIFY_LICENSE') {
    const key = String(msg.licenseKey || msg.key || '').trim();
    if (!key) {
      sendResponse({ ok: false, valid: false, error: 'Please enter a valid license key.' });
      return true;
    }
    verifyLicenseWithServer(key).then((result) => {
      sendResponse(result);
    });
    return true;
  }
});
